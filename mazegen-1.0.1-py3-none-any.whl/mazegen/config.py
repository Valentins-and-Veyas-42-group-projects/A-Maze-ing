from dataclasses import dataclass

from .errors import ConfigError, Diagnostic, Err, Ok

"""Maze configuration."""


@dataclass
class Config:
    """Maze configuration file options."""

    width: int
    height: int
    entry: tuple[int, int]
    exits: tuple[int, int]
    output_file: str = "output.txt"
    perfect: bool = False
    verbose: bool = False
    animation: bool = False
    show_path: bool = False
    force_wait_time: float = 0.5
    speed: int = 1
    algorithm: int = 1
    seed: str | None = None
    wall_color: tuple[int, int, int] | None = None


def parse_config(config_file: str) -> Ok[Config] | Err[ConfigError]:
    """Parse the config file and return a Config object."""

    config = Config(0, 0, (0, 0), (0, 0))

    valid_keys = {
        "WIDTH",
        "HEIGHT",
        "ENTRY",
        "EXIT",
        "OUTPUT_FILE",
        "PERFECT",
        "ANIMATION",
        "SHOW_PATH",
        "SPEED",
        "ALGORITHM",
        "SEED",
        "WALL_COLOR",
    }

    required_keys = {
        "WIDTH",
        "HEIGHT",
        "ENTRY",
        "EXIT",
        "OUTPUT_FILE",
        "PERFECT",
    }

    parsed_values: dict[
        str,
        int | str | tuple[int, int] | tuple[int, int, int] | float | None,
    ] = {}

    try:
        with open(config_file, encoding="utf-8") as f:
            lines = [line.rstrip("\r\n") for line in f.readlines()]

    except FileNotFoundError:
        return Err(ConfigError.ERR_FILE_NOT_FOUND)

    except PermissionError:
        return Err(ConfigError.ERR_CANT_OPEN_FILE)

    entry_line_num = 1
    entry_line_text = ""
    exit_line_num = 1
    exit_line_text = ""

    for idx, raw_line in enumerate(lines, 1):
        stripped = raw_line.strip()

        if not stripped or stripped.startswith("#"):
            continue

        if "=" not in raw_line:
            split_pos = raw_line.find(" ")

            if split_pos == -1:
                split_pos = len(raw_line)

            diag = Diagnostic(
                filename=config_file,
                line_num=idx,
                line_text=raw_line,
                col_start=split_pos,
                col_end=split_pos + 1,
                help_msg="expected '=' to separate key and value",
            )

            return Err(ConfigError.ERR_INVALID_SYNTAX, diag)

        key_part, val_part = raw_line.split("=", 1)

        key = key_part.strip()
        val = val_part.strip()

        match key:
            case "ALGORITHM":
                algorithm_names = {"DFS": 1, "BINARY": 2, "PRIM": 3}

                if val.isdigit():
                    int_val = int(val)

                    if int_val not in (1, 2, 3):
                        start_col = raw_line.find(val)

                        diag = Diagnostic(
                            filename=config_file,
                            line_num=idx,
                            line_text=raw_line,
                            col_start=start_col,
                            col_end=start_col + len(val),
                            help_msg="ALGORITHM must be 1 for DFS, 2 for "
                            + "binary tree, or 3 for Prim's",
                        )

                        return Err(ConfigError.ERR_INVALID_ALGORITHM, diag)

                    parsed_values[key] = int_val
                    required_keys.discard(key)
                    config.algorithm = int_val

                elif val.upper() in algorithm_names:
                    int_val = algorithm_names[val.upper()]

                    parsed_values[key] = int_val
                    required_keys.discard(key)
                    config.algorithm = int_val

                else:
                    start_col = raw_line.find(val)

                    max_allowed_distance = min(3, max(1, int(len(val) * 0.4)))
                    best_match, dist = min(
                        (
                            (
                                name,
                                levenshteinRecursive(
                                    val.upper(),
                                    name,
                                    len(val),
                                    len(name),
                                ),
                            )
                            for name in algorithm_names
                        ),
                        key=lambda item: (
                            item[1],
                            -_common_prefix_len(val.upper(), item[0]),
                            abs(len(val) - len(item[0])),
                            item[0],
                        ),
                    )

                    if dist <= max_allowed_distance:
                        help_msg = (
                            f"Invalid ALGORITHM value '{val}'."
                            f" Did you mean '{best_match}'?"
                            " (valid values: 1/DFS, 2/BINARY, 3/PRIM)"
                        )
                    else:
                        help_msg = (
                            "ALGORITHM must be 1 for DFS,"
                            " 2 for binary tree, 3 for Prim's,"
                            f" or the name DFS/BINARY/PRIM; got '{val}'"
                        )

                    diag = Diagnostic(
                        filename=config_file,
                        line_num=idx,
                        line_text=raw_line,
                        col_start=start_col,
                        col_end=start_col + len(val),
                        help_msg=help_msg,
                    )

                    return Err(ConfigError.ERR_INVALID_ALGORITHM, diag)
            case "WIDTH" | "HEIGHT" | "SPEED":
                try:
                    int_val = int(val)

                    if int_val <= 0:
                        raise ValueError

                    parsed_values[key] = int_val
                    required_keys.discard(key)

                    if key == "WIDTH":
                        config.width = int_val
                    elif key == "HEIGHT":
                        config.height = int_val
                    else:
                        config.speed = int_val

                except ValueError:
                    start_col = raw_line.find(val)
                    help_msg = f"{key} must be a positive integer (e.g., '20')"

                    diag = Diagnostic(
                        filename=config_file,
                        line_num=idx,
                        line_text=raw_line,
                        col_start=start_col,
                        col_end=start_col + len(val),
                        help_msg=help_msg,
                    )

                    int_errors = {
                        "WIDTH": ConfigError.ERR_INVALID_WIDTH,
                        "HEIGHT": ConfigError.ERR_INVALID_HEIGHT,
                        "SPEED": ConfigError.ERR_INVALID_SPEED,
                    }
                    return Err(int_errors[key], diag)

            case "ENTRY" | "EXIT":
                if val.count(",") != 1:
                    first_comma = val.find(",")
                    second_comma = val.find(",", first_comma + 1)

                    if second_comma != -1:
                        start_col = raw_line.find(val) + second_comma
                        end_col = start_col + 1
                    else:
                        start_col = raw_line.find(val)
                        end_col = start_col + len(val)

                    diag = Diagnostic(
                        filename=config_file,
                        line_num=idx,
                        line_text=raw_line,
                        col_start=start_col,
                        col_end=end_col,
                        help_msg=(
                            f"{key} must contain exactly one comma "
                            "separating two integers (e.g., '0,0')"
                        ),
                    )

                    err_type = (
                        ConfigError.ERR_INVALID_ENTRY
                        if key == "ENTRY"
                        else ConfigError.ERR_INVALID_EXIT
                    )

                    return Err(err_type, diag)

                x_raw, y_raw = val.split(",")

                coords: list[int] = []

                for part_raw in (x_raw, y_raw):
                    part_stripped = part_raw.strip()

                    if not part_stripped:
                        start_col = raw_line.find(val)

                        diag = Diagnostic(
                            filename=config_file,
                            line_num=idx,
                            line_text=raw_line,
                            col_start=start_col,
                            col_end=start_col + len(val),
                            help_msg=f"Missing coordinate value in '{val}'",
                        )

                        err_type = (
                            ConfigError.ERR_INVALID_ENTRY
                            if key == "ENTRY"
                            else ConfigError.ERR_INVALID_EXIT
                        )

                        return Err(err_type, diag)

                    if not part_stripped.lstrip("-").isdigit():
                        start_col = raw_line.find(part_stripped)

                        diag = Diagnostic(
                            filename=config_file,
                            line_num=idx,
                            line_text=raw_line,
                            col_start=start_col,
                            col_end=start_col + len(part_stripped),
                            help_msg=(
                                f"Expected an integer, found invalid "
                                f"characters: '{part_stripped}'"
                            ),
                        )

                        err_type = (
                            ConfigError.ERR_INVALID_ENTRY
                            if key == "ENTRY"
                            else ConfigError.ERR_INVALID_EXIT
                        )

                        return Err(err_type, diag)

                    coords.append(int(part_stripped))

                coord_tuple = (coords[0], coords[1])

                parsed_values[key] = coord_tuple
                required_keys.discard(key)

                if key == "ENTRY":
                    config.entry = coord_tuple
                    entry_line_num = idx
                    entry_line_text = raw_line
                else:
                    config.exits = coord_tuple
                    exit_line_num = idx
                    exit_line_text = raw_line

            case "OUTPUT_FILE":
                if not val:
                    start_col = raw_line.find("=") + 1

                    diag = Diagnostic(
                        filename=config_file,
                        line_num=idx,
                        line_text=raw_line,
                        col_start=start_col,
                        col_end=len(raw_line),
                        help_msg="OUTPUT_FILE value cannot be empty",
                    )

                    return Err(
                        ConfigError.ERR_INVALID_OUTPUT_FILE,
                        diag,
                    )

                invalid_chars = set('<>:"/\\|?*')

                found_invalid = [c for c in val if c in invalid_chars]

                if found_invalid:
                    first_bad = next(
                        i for i, c in enumerate(val) if c in invalid_chars
                    )

                    start_col = raw_line.find(val) + first_bad

                    diag = Diagnostic(
                        filename=config_file,
                        line_num=idx,
                        line_text=raw_line,
                        col_start=start_col,
                        col_end=start_col + 1,
                        help_msg=(
                            f"OUTPUT_FILE contains invalid "
                            f"character: '{val[first_bad]}'"
                        ),
                    )

                    return Err(
                        ConfigError.ERR_INVALID_OUTPUT_FILE,
                        diag,
                    )

                parsed_values["OUTPUT_FILE"] = val
                required_keys.discard("OUTPUT_FILE")

                config.output_file = val

            case "SEED":
                if not val:
                    start_col = raw_line.find("=") + 1

                    diag = Diagnostic(
                        filename=config_file,
                        line_num=idx,
                        line_text=raw_line,
                        col_start=start_col,
                        col_end=len(raw_line),
                        help_msg="SEED value cannot be empty",
                    )

                    return Err(ConfigError.ERR_INVALID_SYNTAX, diag)

                parsed_values["SEED"] = val
                config.seed = val

            case "PERFECT" | "ANIMATION" | "SHOW_PATH":
                if val not in ("True", "False"):
                    start_col = raw_line.find(val)

                    diag = Diagnostic(
                        filename=config_file,
                        line_num=idx,
                        line_text=raw_line,
                        col_start=start_col,
                        col_end=start_col + len(val),
                        help_msg=f"{key} must be either 'True' or 'False'",
                    )

                    bool_errors = {
                        "PERFECT": ConfigError.ERR_INVALID_PERFECT,
                        "ANIMATION": ConfigError.ERR_INVALID_ANIMATION,
                        "SHOW_PATH": ConfigError.ERR_INVALID_SHOW_PATH,
                    }
                    return Err(bool_errors[key], diag)

                parsed_values[key] = val
                required_keys.discard(key)

                if key == "PERFECT":
                    config.perfect = val == "True"
                elif key == "ANIMATION":
                    config.animation = val == "True"
                else:
                    config.show_path = val == "True"

            case "WALL_COLOR":
                parts = [part.strip() for part in val.split(",")]
                if len(parts) != 3:
                    start_col = raw_line.find(val)

                    diag = Diagnostic(
                        filename=config_file,
                        line_num=idx,
                        line_text=raw_line,
                        col_start=start_col,
                        col_end=start_col + len(val),
                        help_msg=(
                            "WALL_COLOR must contain three RGB"
                            " integers (e.g., '184,2,44')"
                        ),
                    )

                    return Err(ConfigError.ERR_INVALID_WALL_COLOR, diag)

                try:
                    rgb = tuple(int(part) for part in parts)
                    if any(channel < 0 or channel > 255 for channel in rgb):
                        raise ValueError
                except ValueError:
                    start_col = raw_line.find(val)

                    diag = Diagnostic(
                        filename=config_file,
                        line_num=idx,
                        line_text=raw_line,
                        col_start=start_col,
                        col_end=start_col + len(val),
                        help_msg=(
                            "WALL_COLOR channels must"
                            " be integers from 0 to 255"
                        ),
                    )

                    return Err(ConfigError.ERR_INVALID_WALL_COLOR, diag)

                config.wall_color = (rgb[0], rgb[1], rgb[2])

            case _:
                start_col = 0
                max_allowed_distance = min(3, max(1, int(len(key) * 0.4)))
                best_match, dist = min(
                    (
                        (k, levenshteinRecursive(key, k, len(key), len(k)))
                        for k in valid_keys
                    ),
                    key=lambda item: (
                        item[1],
                        -_common_prefix_len(key, item[0]),
                        abs(len(key) - len(item[0])),
                        item[0],
                    ),
                )
                if dist <= max_allowed_distance:
                    help_msg = (
                        f"Unknown configuration key '{key}'."
                        f" Did you mean '{best_match}'?"
                    )
                else:
                    help_msg = f"Unknown configuration key '{key}'"

                diag = Diagnostic(
                    filename=config_file,
                    line_num=idx,
                    line_text=raw_line,
                    col_start=start_col,
                    col_end=len(key),
                    help_msg=help_msg,
                )
                return Err(ConfigError.ERR_INVALID_SYNTAX, diag)

    if required_keys:
        missing_str = ", ".join(sorted(required_keys))

        diag = Diagnostic(
            filename=config_file,
            line_num=len(lines) if lines else 1,
            line_text=lines[-1] if lines else "",
            col_start=0,
            col_end=1,
            help_msg=(
                f"Missing mandatory configuration options: {missing_str}"
            ),
        )

        return Err(ConfigError.ERR_INVALID_SYNTAX, diag)

    # Validate ENTRY bounds
    entry_x, entry_y = config.entry
    if (
        entry_x < 0
        or entry_x >= config.width
        or entry_y < 0
        or entry_y >= config.height
    ):
        val_str = f"{entry_x},{entry_y}"
        start_col = entry_line_text.find(val_str)
        if start_col == -1:
            start_col = entry_line_text.find("ENTRY") + 5
            col_len = 5
        else:
            col_len = len(val_str)
        diag = Diagnostic(
            filename=config_file,
            line_num=entry_line_num,
            line_text=entry_line_text,
            col_start=start_col,
            col_end=start_col + col_len,
            help_msg=(
                f"ENTRY coordinate ({entry_x}, {entry_y}) is out of bounds "
                f"for maze size {config.width}x{config.height}"
            ),
        )
        return Err(ConfigError.ERR_INVALID_ENTRY, diag)

    # Validate EXIT bounds
    exit_x, exit_y = config.exits
    if (
        exit_x < 0
        or exit_x >= config.width
        or exit_y < 0
        or exit_y >= config.height
    ):
        val_str = f"{exit_x},{exit_y}"
        start_col = exit_line_text.find(val_str)
        if start_col == -1:
            start_col = exit_line_text.find("EXIT") + 4
            col_len = 4
        else:
            col_len = len(val_str)
        diag = Diagnostic(
            filename=config_file,
            line_num=exit_line_num,
            line_text=exit_line_text,
            col_start=start_col,
            col_end=start_col + col_len,
            help_msg=(
                f"EXIT coordinate ({exit_x}, {exit_y}) is out of bounds "
                f"for maze size {config.width}x{config.height}"
            ),
        )
        return Err(ConfigError.ERR_INVALID_EXIT, diag)

    # Validate ENTRY and EXIT are not identical
    if config.entry == config.exits:
        val_str = f"{exit_x},{exit_y}"
        start_col = exit_line_text.find(val_str)
        if start_col == -1:
            start_col = exit_line_text.find("EXIT") + 4
            col_len = 4
        else:
            col_len = len(val_str)
        diag = Diagnostic(
            filename=config_file,
            line_num=exit_line_num,
            line_text=exit_line_text,
            col_start=start_col,
            col_end=start_col + col_len,
            help_msg="EXIT coordinate cannot be the same as ENTRY coordinate",
        )
        return Err(ConfigError.ERR_INVALID_EXIT, diag)

    return Ok(config)


def levenshteinRecursive(
    str1: str, str2: str, len_str1: int, len_str2: int
) -> int:
    """Calculates the Levenshtein distance between two strings recursively."""
    if len_str1 == 0:
        return len_str2
    if len_str2 == 0:
        return len_str1
    if str1[len_str1 - 1] == str2[len_str2 - 1]:
        return levenshteinRecursive(str1, str2, len_str1 - 1, len_str2 - 1)
    return 1 + min(
        levenshteinRecursive(str1, str2, len_str1, len_str2 - 1),
        min(
            levenshteinRecursive(str1, str2, len_str1 - 1, len_str2),
            levenshteinRecursive(str1, str2, len_str1 - 1, len_str2 - 1),
        ),
    )


def _common_prefix_len(str1: str, str2: str) -> int:
    """Return the number of leading characters shared by two strings."""

    count = 0
    for char1, char2 in zip(str1, str2, strict=False):
        if char1 != char2:
            break
        count += 1
    return count
